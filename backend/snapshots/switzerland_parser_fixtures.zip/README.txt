Unchanged selected native SNB JSON series, SECO nominal GDP CSV rows/metadata and the direct BIS CHF index. All observations are official published values.
