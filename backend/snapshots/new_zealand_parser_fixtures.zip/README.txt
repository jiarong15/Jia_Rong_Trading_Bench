Unchanged selected rows from Stats NZ native BOP/GDP CSV releases, full native Infoshare exports/imports query, and direct BIS M.N.B.NZ CSV. Values are never synthesized.
